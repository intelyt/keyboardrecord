package main

import (
	"github.com/gin-contrib/gzip"
	"github.com/gin-gonic/gin"
	"github.com/gobuffalo/packr"
)

type Cities struct{
	Id string `json:"id"`
	Name_cn string `json:"name_cn"`
	Name_en string `json:"name_en"`
}

type Province struct {
	Id string `json:"id"`
	Name_cn string `json:"name_cn"`
	Name_en string `json:"name_en"`
	Cities [] Cities `json:"cities"`
}

type Country struct {
	Data [] Province `json:"data"`
}

var router = gin.Default()

func province(){
	router.Use(gzip.Gzip(gzip.DefaultCompression))
	box := packr.NewBox("./templates")


	router.GET("/province", func(c *gin.Context) {
		//data, err := ioutil.ReadFile("province.json")
		//if err != nil {
		//	fmt.Println("File reading error", err)
		//	return
		//}
		data,_:=box.FindString("json/province.json")
		c.String(200, string(data))
	})

	router.GET("/country", func(c *gin.Context) {
		//data, err := ioutil.ReadFile("vehicles.json")
		//if err != nil {
		//	fmt.Println("File reading error", err)
		//	return
		//}
		data,_:=box.FindString("json/vehicles.json")
		c.String(200, string(data))
	})

	_ = router.Run()
}


func main() {

	gin.SetMode(gin.ReleaseMode)
	province()
	//data, err := ioutil.ReadFile("province.json")
	//if err != nil {
	//	fmt.Println("File reading error", err)
	//	return
	//}
	//
	//var c Country
	//e := json.Unmarshal([]byte(string(data)), &c)
	//if e != nil {
	//	fmt.Println(e)
	//}
	//for _, province := range c.Data {
	//	fmt.Printf("%v %v %v \n", province.Id, province.Name_cn, province.Name_en)
	//	for _, city := range province.Cities {
	//		fmt.Printf("%v %v %v \n", city.Id, city.Name_cn, city.Name_en)
	//
	//	}
	//}
}