from urllib import request
import json

def getResponse(url,pageIndex ):

    data = {"hotelId":661069,"pageIndex": pageIndex,"tagId":0,"pageSize":10,
            "groupTypeBitMap":2,"needStatisticInfo":0,"order":0,"basicRoomName":"","travelType":-1,
            "head":{"cid":"09031144211504567945","ctok":"","cver":"1.0","lang":"01","sid":"8888","syscode":"09","auth":"","extension":[]}}
    data = json.dumps(data).encode(encoding='utf-8')


    header_dict = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko',"Content-Type": "application/json"}

    url_request = request.Request(url=url,data=data,headers=header_dict)
    print("这个对象的方法是：",url_request.get_method())

    url_response = request.urlopen(url_request)

    return url_response
i = 0
while  True:
    i = i + 1
    http_response = getResponse("http://m.ctrip.com/restapi/soa2/16765/gethotelcomment?_fxpcqlniredt=09031144211504567945", i )

    data = http_response.read().decode('utf-8')
    print(data)