package com.example.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.utils.GetDataFromNet;

import java.io.IOException;

// @RestController的意思就是controller里面的方法都以json格式输出

@RestController
public class IndexController {

    public String bmwData = GetDataFromNet.getBMWChinaProvinceCityData();
    public String teslaData = GetDataFromNet.getTeslaChinaProvinceCityData();
    public String xiaoPengData = GetDataFromNet.getXiaoPengChinaProvinceCityData();
    public IndexController() throws IOException {
    }

    @RequestMapping("/")
    public String index() {
        return "index";
    }
    @RequestMapping("/api&company=bmw")
    public String bmw() {
        return bmwData;
    }

    @RequestMapping("/api&company=tesla")
    public String tesla() {
        return teslaData;
    }

    @RequestMapping("/api&company=xiaopeng")
    public String xiaopeng() {
        return xiaoPengData;
    }
}


