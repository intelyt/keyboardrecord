package com.example.utils;

import org.jsoup.Connection;
import org.jsoup.Jsoup;

import java.io.IOException;
import java.util.HashMap;

public class GetDataFromNet {
    public static String BMWAfterSalesShopsDataUrl = "https://cn-digital2-app.bmw.com.cn/dlo/v1/outlets?brand_id=1";
    public static String TeslaDataUrl = "https://www.tesla.cn/cua-api/tesla-locations?translate=zh_CN&map=baidu";
    public static String XiaoPengDataUrl = "https://www.xiaopeng.com/api/store/queryAll";


    public static HashMap<String, String > headers  = new HashMap<String, String>(){{
        put("Accept", "*/*");
        put("Accept-Encoding", "gzip, deflate");
        put("Accept-Language","zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3");
        put("Content-Type", "application/json;charset=UTF-8");
        put("User-Agent","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:48.0) Gecko/20100101 Firefox/48.0");
    }};


    public static String getBMWChinaProvinceCityData() throws IOException {
        Connection.Response res = Jsoup.connect(BMWAfterSalesShopsDataUrl).headers(headers)
                .timeout(10000).ignoreContentType(true).execute();
        if (String.valueOf(res.statusCode()).startsWith("2")  ){
            return res.body();
        }else {
            return null;
        }
    }

    public static String getTeslaChinaProvinceCityData() throws IOException {
        Connection.Response res = Jsoup.connect(TeslaDataUrl).headers(headers)
                .timeout(10000).ignoreContentType(true).execute();
        if (String.valueOf(res.statusCode()).startsWith("2")  ){
            return res.body();
        }else {
            return null;
        }
    }

    public static String getXiaoPengChinaProvinceCityData() throws IOException {
        Connection.Response res = Jsoup.connect(XiaoPengDataUrl).headers(headers)
                .timeout(10000).method(Connection.Method.POST).execute();
        if (String.valueOf(res.statusCode()).startsWith("2")  ){
            return res.body();
        }else {
            return null;
        }
    }

}



