/*
Navicat MySQL Data Transfer

Source Server         : tencent
Source Server Version : 50505
Source Host           : 49.234.179.76:3306
Source Database       : bmw_db

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2021-02-01 15:52:35
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `BMWAfterSalesShopsData`
-- ----------------------------
DROP TABLE IF EXISTS `BMWAfterSalesShopsData`;
CREATE TABLE `BMWAfterSalesShopsData` (
  `addr_cn` varchar(255) DEFAULT NULL,
  `addr_en` varchar(255) DEFAULT NULL,
  `bp_id` varchar(255) DEFAULT NULL,
  `cbu_no` int(10) DEFAULT NULL,
  `city_id` varchar(255) DEFAULT NULL,
  `ckd_no` int(10) DEFAULT NULL,
  `coordinates` text DEFAULT NULL,
  `dealer_id` int(10) DEFAULT NULL,
  `dp_no` int(10) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `id` varchar(255) NOT NULL,
  `is_eretail` tinyint(4) DEFAULT NULL,
  `is_primary` tinyint(4) DEFAULT NULL,
  `lat` varchar(255) DEFAULT NULL,
  `lng` varchar(255) DEFAULT NULL,
  `mon_fri_from` varchar(255) DEFAULT NULL,
  `mon_fri_to` varchar(255) DEFAULT NULL,
  `name_cn` varchar(255) DEFAULT NULL,
  `name_en` varchar(255) DEFAULT NULL,
  `og_link` varchar(255) DEFAULT NULL,
  `primary_biz` text DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `province_id` varchar(255) DEFAULT NULL,
  `region` varchar(255) DEFAULT NULL,
  `retail_format` varchar(255) DEFAULT NULL,
  `sat_from` varchar(255) DEFAULT NULL,
  `sat_to` varchar(255) DEFAULT NULL,
  `service_types` text DEFAULT NULL,
  `shortname_cn` varchar(255) DEFAULT NULL,
  `sun_from` varchar(255) DEFAULT NULL,
  `sun_to` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `wechat` varchar(255) DEFAULT NULL,
  `weibo` varchar(255) DEFAULT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_update_by` varchar(255) DEFAULT NULL,
  `insert_date` date NOT NULL,
  `insert_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`,`insert_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of BMWAfterSalesShopsData
-- ----------------------------

-- ----------------------------
-- Table structure for `BMWChinaProvinceCityData`
-- ----------------------------
DROP TABLE IF EXISTS `BMWChinaProvinceCityData`;
CREATE TABLE `BMWChinaProvinceCityData` (
  `province_id` varchar(255) DEFAULT NULL,
  `province_name_cn` varchar(255) DEFAULT NULL,
  `province_name_en` varchar(255) DEFAULT NULL,
  `province_original_json_text` text DEFAULT NULL,
  `city_id` varchar(255) NOT NULL DEFAULT '',
  `city_name_cn` varchar(255) DEFAULT NULL,
  `city_name_en` varchar(255) DEFAULT NULL,
  `city_original_json_text` text DEFAULT NULL,
  `insert_date` date DEFAULT NULL,
  `insert_datetime` datetime DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_update_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`city_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of BMWChinaProvinceCityData
-- ----------------------------
