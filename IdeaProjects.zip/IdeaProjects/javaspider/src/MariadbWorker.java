import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;

import java.sql.SQLException;

public class MariadbWorker {
    public static final String USER = "taoyin";
    public static final String PASSWORD = "yt.123456";
    private static final String DRIVER = "org.mariadb.jdbc.Driver";
    private static final String URL ="jdbc:mariadb://49.234.179.76:3306/bmw_db";

    /**获取一个数据库连接**/
    public static java.sql.Connection getConnection() throws SQLException, ClassNotFoundException {
        Class.forName(DRIVER);
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    /** 判断数据库是否支持批处理 */
    public static boolean supportBatch(Connection con) {
        try {
            // 得到数据库的元数据
            DatabaseMetaData md = con.getMetaData();
            return md.supportsBatchUpdates();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

}
