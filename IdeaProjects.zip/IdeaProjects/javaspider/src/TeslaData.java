public class TeslaData implements java.io.Serializable {
    public String           location_id;
    public String           latitude;
    public String           longitude;
    //public String           location_type;
    public String           open_soon;

}

