public class DatabaseDesign {

    public static String
            insertBMWChinaProvinceCityDataSQL =
            "INSERT IGNORE INTO BMWChinaProvinceCityData(" +
                    "province_id, " +
                    "province_name_cn," +
                    "province_name_en," +
                    "province_original_json_text," +
                    "city_id," +
                    "city_name_cn," +
                    "city_name_en, " +
                    "city_original_json_text, " +
                    "insert_date, " +
                    "insert_datetime," +
                    "country, " +
                    "brand, " +
                    "created_by," +
                    "last_update_by) " +
                    "VALUES(" +
                    "?," +
                    "?," +
                    "?," +
                    "?," +
                    "?," +
                    "?," +
                    "?," +
                    "?," +
                    "?," +
                    "?," +
                    "?," +
                    "?," +
                    "?," +
                    "?);";

    public static String
            insertBMWAfterSalesShopsDataSQL= "INSERT IGNORE INTO BMWAfterSalesShopsData(" +
            "addr_cn," +
            "addr_en," +
            "bp_id," +
            "cbu_no," +
            "city_id," +
            "ckd_no," +
            "coordinates," +
            "dealer_id," +
            "dp_no," +
            "email," +
            "fax," +
            "id," +
            "is_eretail," +
            "is_primary," +
            "lat," +
            "lng," +
            "mon_fri_from," +
            "mon_fri_to," +
            "name_cn," +
            "name_en," +
            "og_link," +
            "primary_biz," +
            "profile_image," +
            "province_id," +
            "region," +
            "retail_format," +
            "sat_from," +
            "sat_to," +
            "service_types," +
            "shortname_cn," +
            "sun_from," +
            "sun_to," +
            "tel," +
            "website," +
            "wechat," +
            "weibo," +
            "brand," +
            "country," +
            "created_by," +
            "last_update_by," +
            "insert_date," +
            "insert_datetime)" +
            " VALUES(" +
            "?," + //addr_cn
            "?," + //addr_en
            "?," + //bp_id
            "?," + //cbu_no
            "?," + //city_id
            "?," + //ckd_no
            "?," + //coordinates
            "?," + //dealer_id
            "?," + //dp_no
            "?," + //email
            "?," + //fax
            "?," + //id
            "?," + //is_eretail
            "?," + //is_primary
            "?," + //lat
            "?," + //lng
            "?," + //mon_fri_from
            "?," + //mon_fri_to
            "?," + //name_cn
            "?," + //name_en
            "?," + //og_link
            "?," + //primary_biz
            "?," + //profile_image
            "?," + //province_id
            "?," + //region
            "?," + //retail_format
            "?," + //sat_from
            "?," + //sat_to
            "?," + //service_types
            "?," + //shortname_cn
            "?," + //sun_from
            "?," + //sun_to
            "?," + //tel
            "?," + //website
            "?," + //wechat
            "?," + //weibo
            "?," + //brand
            "?," + //country
            "?," + //created_by
            "?," + //last_update_by
            "?," + //insert_date
            "?);"; //insert_datetime


}
