import com.google.gson.Gson;
import org.jsoup.Connection;
import org.jsoup.Jsoup;


import java.io.IOException;
import java.util.HashMap;


class GetDataFromNet {
    public static String BMWChinaProvinceCityDataUrl = "https://cn-digital2-app.bmw.com.cn/dlo/v1/locales?brand_id=1";
    public static String BMWAfterSalesShopsDataUrl = "https://cn-digital2-app.bmw.com.cn/dlo/v1/outlets?brand_id=1";

    public static HashMap<String, String > headers  = new HashMap<String, String>(){{
        put("Accept", "*/*");
        put("Accept-Encoding", "gzip, deflate");
        put("Accept-Language","zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3");
        put("Content-Type", "application/json;charset=UTF-8");
        put("User-Agent","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:48.0) Gecko/20100101 Firefox/48.0");
    }};

    public static BMWAfterSalesShopsData getBMWAfterSalesShopsData() throws IOException {
        Connection.Response res = Jsoup.connect(BMWAfterSalesShopsDataUrl).headers(headers)
                .timeout(10000).ignoreContentType(true).execute();
        if (String.valueOf(res.statusCode()).startsWith("2")  ){
            String body = res.body();
            Gson gson = new Gson();
            return gson.fromJson(body, BMWAfterSalesShopsData.class);
        }else {
            return null;
        }
    }

    public static BMWChinaProvinceCityData getBMWChinaProvinceCityData() throws IOException {
        Connection.Response res = Jsoup.connect(BMWChinaProvinceCityDataUrl).headers(headers)
                .timeout(10000).ignoreContentType(true).execute();
        if (String.valueOf(res.statusCode()).startsWith("2")  ){
            String body = res.body();
            Gson gson = new Gson();
            return gson.fromJson(body, BMWChinaProvinceCityData.class);
        }else {
            return null;
        }
    }

}



