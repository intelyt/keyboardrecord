public class BMWAfterSalesShopsData implements java.io.Serializable
{
    public SubBMW[] getData() {
        return data;
    }

    private SubBMW[] data;

}

class SubBMW implements java.io.Serializable
{
    private String addr_cn;
    private String addr_en;
    private String bp_id;
    private String cbu_no;

    private String city_id;
    private String ckd_no;
    private Coordinates coordinates;//
    private String dealer_id;
    private String dp_no;
    private String email;
    private String fax;
    private String  id;
    private boolean  is_primary;
    private String lat;
    private String lng;
    private String mon_fri_from;
    private String mon_fri_to;
    private boolean is_eretail;
    private String name_cn;
    private String name_en;
    private String og_link;
    private Primary_biz[] primary_biz;//
    private String profile_image;
    private String province_id;
    private String region;
    private String retail_format;
    private String sat_from;
    private String sat_to;
    private Service_types[] service_types;//
    private String shortname_cn;
    private String sun_from;
    private String sun_to;
    private String tel;
    private String website;
    private String wechat;
    private String weibo;

    SubBMW() {
    }

    public String getAddr_cn() {
        return addr_cn;
    }

    public String getAddr_en() {
        return addr_en;
    }
    public String getBp_id() {
        return bp_id;
    }

    public String getCbu_no() {
        return cbu_no;
    }

    public String getCity_id() {
        return city_id;
    }

    public String getCkd_no() {
        return ckd_no;
    }

    public Coordinates getCoordinates() {
        return coordinates;
    }

    public String getDealer_id() {
        return dealer_id;
    }

    public String getDp_no() {
        return dp_no;
    }

    public String getEmail() {
        return email;
    }

    public String getFax() {
        return fax;
    }

    public String getId() {
        return id;
    }

    public boolean getIs_eretail() {
        return is_eretail;
    }

    public boolean getIs_primary() {
        return is_primary;
    }

    public String getLat() {
        return lat;
    }

    public String getLng() {
        return lng;
    }

    public String getMon_fri_from() {
        return mon_fri_from;
    }

    public String getMon_fri_to() {
        return mon_fri_to;
    }

    public String getName_cn() {
        return name_cn;
    }


    public String getName_en() {
        return name_en;
    }


    public String getOg_link() {
        return og_link;
    }


    public Primary_biz[] getPrimary_biz() {
        return primary_biz;
    }


    public String getProfile_image() {
        return profile_image;
    }

    public String getProvince_id() {
        return province_id;
    }

    public String getRegion() {
        return region;
    }

    public String getRetail_format() {
        return retail_format;
    }

    public String getSat_from() {
        return sat_from;
    }


    public String getSat_to() {
        return sat_to;
    }


    public Service_types[] getService_types() {
        return service_types;
    }


    public String getShortname_cn() {
        return shortname_cn;
    }


    public String getSun_from() {
        return sun_from;
    }


    public String getSun_to() {
        return sun_to;
    }


    public String getTel() {
        return tel;
    }

    public String getWebsite() {
        return website;
    }


    public String getWechat() {
        return wechat;
    }

    public String getWeibo() {
        return weibo;
    }

}

class Coordinates implements java.io.Serializable{
    private LatLng amap;
    private LatLng baidu;
    private LatLng tencent;
}

class LatLng implements java.io.Serializable{
    private String lat;
    private String lng;
}

class Primary_biz implements java.io.Serializable {
    private String id;
    private String name_cn;
    private String name_en;
    private String code;
    private String contact;
    private String display_order;




}

class Service_types implements java.io.Serializable{
    private String id;
    private String name_cn;
    private String name_en;
    private String code;
    private String display_order;

}

