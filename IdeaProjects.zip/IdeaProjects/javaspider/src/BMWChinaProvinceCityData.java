public class BMWChinaProvinceCityData implements java.io.Serializable
{
    public Province[] data;
}

class Province implements java.io.Serializable{
    private String name_cn;
    private String id;
    private String name_en;
    private City[] cities;
    public String getName_cn() {
        return name_cn;
    }

    public String getId() {
        return id;
    }

    public String getName_en() {
        return name_en;
    }

    public City[] getCities() {
        return cities;
    }


}


class City implements java.io.Serializable{
    private String id;
    private String name_en;
    private String name_cn;

    public String getId() {
        return id;
    }

    public String getName_en() {
        return name_en;
    }

    public String getName_cn() {
        return name_cn;
    }

}



