import com.google.gson.Gson;

import java.sql.*;
import java.io.IOException;

import java.text.DateFormat;
import java.util.Date;
import java.text.SimpleDateFormat;


public class StoreToDatabase {
    public static String brand = "BMW";
    public static String country = "China";
    public static String created_by = "taoyin";
    public static String last_update_by = "taoyin";
    public  Date date = new Date();

    public static java.sql.Connection conn;
    static {
        try {
            conn = MariadbWorker.getConnection();
            conn.setAutoCommit(false);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static boolean supportBatch = MariadbWorker.supportBatch(conn);

    public static int parseB(boolean value){
        if (value){
            return 1;
        }else {
            return 0;
        }
    }


    public  void insertBMWChinaProvinceCityData() throws IOException, SQLException {

        PreparedStatement preparedStatement = conn.prepareStatement(DatabaseDesign.insertBMWChinaProvinceCityDataSQL);

        String province_id;
        String province_name_cn;
        String province_name_en;
        String province_original_json_text;
        String city_id;
        String city_name_cn;
        String city_name_en;
        String city_original_json_text;


        BMWChinaProvinceCityData bMWChinaProvinceCityData = GetDataFromNet.getBMWChinaProvinceCityData();

        assert bMWChinaProvinceCityData != null;
        for (int i = 0; i< bMWChinaProvinceCityData.data.length; i++){
            province_id = bMWChinaProvinceCityData.data[i].getId();
            province_name_cn = bMWChinaProvinceCityData.data[i].getName_cn();
            province_name_en = bMWChinaProvinceCityData.data[i].getName_en();
            province_original_json_text = new Gson().toJson(bMWChinaProvinceCityData.data[i].getCities());
            for (int j = 0; j< bMWChinaProvinceCityData.data[i].getCities().length; j++){
                city_id = bMWChinaProvinceCityData.data[i].getCities()[j].getId();
                city_name_cn = bMWChinaProvinceCityData.data[i].getCities()[j].getName_cn();
                city_name_en = bMWChinaProvinceCityData.data[i].getCities()[j].getName_en();
                city_original_json_text =  new Gson().toJson(bMWChinaProvinceCityData.data[i].getCities()[j]);

                preparedStatement.setString(1, province_id);
                preparedStatement.setString(2, province_name_cn);
                preparedStatement.setString(3, province_name_en);
                preparedStatement.setString(4, province_original_json_text);
                preparedStatement.setString(5, city_id);
                preparedStatement.setString(6, city_name_cn);
                preparedStatement.setString(7, city_name_en);
                preparedStatement.setString(8, city_original_json_text);


                DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                String insert_date  = format.format(date);

                DateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String insert_datetime  = f.format(date);
                preparedStatement.setString(9, insert_date);
                preparedStatement.setString(10, insert_datetime);
                preparedStatement.setString(11, country);
                preparedStatement.setString(12, brand);
                preparedStatement.setString(13, created_by);
                preparedStatement.setString(14, last_update_by);
                if (!supportBatch){
                    preparedStatement.executeUpdate(); //单条提交
                    conn.commit();//单条提交
                }
                else {preparedStatement.addBatch();
                }
            }
            if(supportBatch){
                preparedStatement.executeBatch();
                conn.commit();
                preparedStatement.clearBatch();
            }
        }
        preparedStatement.close();
    }

    public void insertBMWAfterSalesShopsData() throws IOException, SQLException {
        PreparedStatement preparedStatement = conn.prepareStatement(DatabaseDesign.insertBMWAfterSalesShopsDataSQL);
        Date date = new Date();
        String addr_cn;
        String addr_en;
        String bp_id;
        String cbu_no;
        String city_id;
        String ckd_no;
        String coordinates;
        String dealer_id;
        String dp_no;
        String email;
        String fax;
        String id;
        boolean is_eretail;
        boolean is_primary;
        String lat;
        String lng;
        String mon_fri_from;
        String mon_fri_to;
        String name_cn;
        String name_en;
        String og_link;
        String primary_biz;
        String profile_image;
        String province_id;
        String region;
        String retail_format;
        String sat_from;
        String sat_to;
        String service_types;
        String shortname_cn;
        String sun_from;
        String sun_to;
        String tel;
        String website;
        String wechat;
        String weibo;


        BMWAfterSalesShopsData bMWAfterSalesShopsData = GetDataFromNet.getBMWAfterSalesShopsData();
        assert bMWAfterSalesShopsData != null;
        for (int i = 0; i< bMWAfterSalesShopsData.getData().length; i++){
            addr_cn          = bMWAfterSalesShopsData.getData()[i].getAddr_cn();
            preparedStatement.setString(1, addr_cn);
            addr_en          = bMWAfterSalesShopsData.getData()[i].getAddr_en();
            preparedStatement.setString(2, addr_en);
            bp_id            = bMWAfterSalesShopsData.getData()[i].getBp_id();
            preparedStatement.setString(3, bp_id);
            cbu_no           = bMWAfterSalesShopsData.getData()[i].getCbu_no();
            preparedStatement.setString(4, cbu_no );
            city_id          = bMWAfterSalesShopsData.getData()[i].getCity_id();
            preparedStatement.setString(5, city_id );
            ckd_no           = bMWAfterSalesShopsData.getData()[i].getCkd_no();
            preparedStatement.setString(6, ckd_no );
            coordinates      = new Gson().toJson(bMWAfterSalesShopsData.getData()[i].getCoordinates());
            preparedStatement.setString(7, coordinates );
            dealer_id        = bMWAfterSalesShopsData.getData()[i].getDealer_id();
            preparedStatement.setString(8, dealer_id );
            dp_no            = bMWAfterSalesShopsData.getData()[i].getDp_no();
            preparedStatement.setString(9, dp_no );
            email            = bMWAfterSalesShopsData.getData()[i].getEmail();
            preparedStatement.setString(10, email );
            fax              = bMWAfterSalesShopsData.getData()[i].getFax();
            preparedStatement.setString(11, fax );
            id               = bMWAfterSalesShopsData.getData()[i].getId();
            preparedStatement.setString(12, id );
            is_eretail       = bMWAfterSalesShopsData.getData()[i].getIs_eretail();
            preparedStatement.setInt(13, parseB(is_eretail));
            is_primary       = bMWAfterSalesShopsData.getData()[i].getIs_primary();
            preparedStatement.setInt(14,parseB(is_primary));
            lat              = bMWAfterSalesShopsData.getData()[i].getLat();
            preparedStatement.setString(15, lat);
            lng              = bMWAfterSalesShopsData.getData()[i].getLng();
            preparedStatement.setString(16, lng);
            mon_fri_from     = bMWAfterSalesShopsData.getData()[i].getMon_fri_from();
            preparedStatement.setString(17, mon_fri_from );
            mon_fri_to       = bMWAfterSalesShopsData.getData()[i].getMon_fri_to();
            preparedStatement.setString(18, mon_fri_to );
            name_cn          = bMWAfterSalesShopsData.getData()[i].getName_cn();
            preparedStatement.setString(19, name_cn );
            name_en          = bMWAfterSalesShopsData.getData()[i].getName_en();
            preparedStatement.setString(20, name_en );
            og_link          = bMWAfterSalesShopsData.getData()[i].getOg_link();
            preparedStatement.setString(21, og_link );
            primary_biz      = new Gson().toJson(bMWAfterSalesShopsData.getData()[i].getPrimary_biz());

            preparedStatement.setString(22, primary_biz );
            profile_image    = bMWAfterSalesShopsData.getData()[i].getProfile_image();
            preparedStatement.setString(23, profile_image );
            province_id      = bMWAfterSalesShopsData.getData()[i].getProvince_id();
            preparedStatement.setString(24, province_id );
            region           = bMWAfterSalesShopsData.getData()[i].getRegion();
            preparedStatement.setString(25, region );
            retail_format    = bMWAfterSalesShopsData.getData()[i].getRetail_format();
            preparedStatement.setString(26, retail_format );
            sat_from         = bMWAfterSalesShopsData.getData()[i].getSat_from();
            preparedStatement.setString(27, sat_from );
            sat_to           = bMWAfterSalesShopsData.getData()[i].getSat_to();
            preparedStatement.setString(28, sat_to );
            service_types    = new Gson().toJson(bMWAfterSalesShopsData.getData()[i].getService_types());
            preparedStatement.setString(29, service_types );

            shortname_cn     = bMWAfterSalesShopsData.getData()[i].getShortname_cn();
            preparedStatement.setString(30, shortname_cn );
            sun_from         = bMWAfterSalesShopsData.getData()[i].getSun_from();
            preparedStatement.setString(31, sun_from );
            sun_to           = bMWAfterSalesShopsData.getData()[i].getSun_to();
            preparedStatement.setString(32, sun_to );
            tel              = bMWAfterSalesShopsData.getData()[i].getTel();
            preparedStatement.setString(33, tel );
            website          = bMWAfterSalesShopsData.getData()[i].getWebsite();
            preparedStatement.setString(34, website );
            wechat           = bMWAfterSalesShopsData.getData()[i].getWechat();
            preparedStatement.setString(35, wechat );
            weibo            = bMWAfterSalesShopsData.getData()[i].getWeibo();
            preparedStatement.setString(36, weibo );
            preparedStatement.setString(37, brand );
            preparedStatement.setString(38, country);
            preparedStatement.setString(39, created_by);
            DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            String insert_date  = format.format(date);

            DateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String insert_datetime  = f.format(date);
            preparedStatement.setString(40, last_update_by);
            preparedStatement.setString(41, insert_date);
            preparedStatement.setString(42, insert_datetime);
            if (!supportBatch){
                preparedStatement.executeUpdate(); //单条提交
                conn.commit();//单条提交
            }
            else {preparedStatement.addBatch();
            }


        }
        if(supportBatch){
            preparedStatement.executeBatch();
            conn.commit();
            preparedStatement.clearBatch();
        }
        preparedStatement.close();


    }



    public static void main(String[] args) throws IOException, SQLException {
        Long beginTime = System.currentTimeMillis();
        StoreToDatabase s = new StoreToDatabase();
        s.insertBMWChinaProvinceCityData();
        s.insertBMWAfterSalesShopsData();

        conn.close();
        Long endTime = System.currentTimeMillis();
        System.out.println("pst+batch："+(endTime-beginTime)/1000+"秒");

    }

}


