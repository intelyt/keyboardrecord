import com.google.gson.*;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.IOException;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;;

public class Tesla {

    public static String teslaLocationUrl = "https://www.tesla.cn/cua-api/tesla-locations?map=baidu";
    public static CloseableHttpClient httpClient = HttpClients.createDefault();



    public static String unicodeToString(String str) {

        Pattern pattern = Pattern.compile("(\\\\u(\\p{XDigit}{4}))");
        Matcher matcher = pattern.matcher(str);
        char ch;
        while (matcher.find()) {
            String group = matcher.group(2);
            ch = (char) Integer.parseInt(group, 16);
            String group1 = matcher.group(1);
            str = str.replace(group1, ch + "");
        }
        return str;
    }


        public static String getResponseText (String url) throws IOException {
        HttpGet httpget = new HttpGet(url){{
        }};
        CloseableHttpResponse response = httpClient.execute(httpget);
        if(response.getStatusLine().getStatusCode()==200){
            HttpEntity entity = response.getEntity();
            String responseText = EntityUtils.toString(entity, "utf-16");
            httpget.releaseConnection();
            response.close();
            return responseText;
        }else return null;
    }


    public static <T> List<T> getObjectList(String jsonString,Class<T> cls) {
        List<T> list = new ArrayList<T>();
        try {
            Gson gson = new Gson();
            JsonArray arry = JsonParser.parseString(jsonString).getAsJsonArray();
            for (JsonElement jsonElement : arry) {
                list.add(gson.fromJson(jsonElement, cls));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }


    public static void getData() throws IOException {
        List<TeslaData> data = getObjectList(getResponseText(teslaLocationUrl), TeslaData.class);
        for (TeslaData datum : data) {
            String url = "https://www.tesla.cn/cua-api/tesla-location?id=" + datum.location_id + "&map=baidu";
            System.out.println(unicodeToString(getResponseText(url)));


        }

    }


    public static void main(String[] args) throws IOException {
        getData();

        httpClient.close();



    }
}
