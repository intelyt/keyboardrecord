import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class LianjiaHouse {
    public static String indexURL = "https://www.lianjia.com/city/";

    public static HashMap<String, String> headers = new HashMap<String, String>() {{
        put("Accept", "*/*");
        put("Accept-Encoding", "gzip, deflate");
        put("Accept-Language", "zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3");
        put("Content-Type", "application/json;charset=UTF-8");
        put("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:48.0) Gecko/20100101 Firefox/48.0");
    }};

    public ArrayList<DataModel> getCities() throws IOException {
        ArrayList<DataModel> dataModels = new ArrayList<DataModel>();
        Document doc = Jsoup.connect(indexURL).headers(headers)
                .timeout(10000).ignoreContentType(true).get();
        Elements cityProvinceList = doc.select(".city_list_ul >li");
        for (Element cityProvince : cityProvinceList) {
            String cityProvinceFirstAlpha = cityProvince.select(".city_firstletter >span").text();
            String cityProvinceName = cityProvince.select(".city_province").select(".city_list_tit.c_b").text();

            Elements cityList = cityProvince.select(".city_province >ul >li >a");
            for (Element city : cityList) {
                String cityUrl = city.attr("href");
                String cityName = city.text();
                DataModel d = new DataModel();
                d.cityProvinceFirstAlpha = cityProvinceFirstAlpha;
                d.cityProvinceName = cityProvinceName;
                d.cityUrl = cityUrl;
                d.cityName = cityName;
                dataModels.add(d);
            }
        }
        return dataModels;
    }

    public void getData() throws IOException {

        for(DataModel d: getCities()){
            Document doc  = Jsoup.connect(d.cityUrl).headers(headers)
                    .timeout(10000).ignoreContentType(true).get();
            System.out.println(doc.outerHtml());

        }


    }








    public static void main(String[] args) throws IOException {
        LianjiaHouse lj = new LianjiaHouse();
        lj.getData();

    }
}




//    public void getData() throws IOException {
//        Document doc  = Jsoup.connect(indexURL).headers(headers)
//                .timeout(10000).ignoreContentType(true).get();
//
//        Elements categoryElements = doc.select("div.position >dl [data-role]");
//        for (Element categoryElement:categoryElements){
//            Elements subCategoryElements = categoryElement.select("a");
//            for (Element subCategoryElement: subCategoryElements){
//                String href = subCategoryElement.attr("href");
//                String title = subCategoryElement.attr("title");
//                String text = subCategoryElement.text();
////                Document d  = Jsoup.connect().headers(headers)
////                        .timeout(10000).ignoreContentType(true).get();
//            }
//    }