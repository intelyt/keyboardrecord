public class DataModel implements java.io.Serializable{
    public String       cityProvinceFirstAlpha;
    public String       cityProvinceName;
    public String       cityUrl;
    public String       cityName;
    public String       area;
    public String       subwayNo;
    public String       ershoufang;


}

